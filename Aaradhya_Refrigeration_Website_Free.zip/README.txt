AARADHYA REFRIGERATION WEBSITE
Files:
- index.html: complete mobile-friendly website

How to publish free:
1. Create/sign in to a GitHub account.
2. Create a PUBLIC repository named aaradhya-refrigeration-website.
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for GitHub Pages to publish. Your public link will be shown in Settings > Pages.

Note: This is a static enquiry website. The booking form opens WhatsApp with the customer's details; it does not store bookings in a database.
Before publishing, verify the phone number, email, service list and service area.
